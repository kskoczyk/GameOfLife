#include "Cell.h"

void Cell::setState(bool &&newState)
{
	isAlive = newState;
}

Cell::Cell(bool &&alive)
{
	isAlive = alive;
}

bool Cell::getState()
{
	return isAlive;
}
