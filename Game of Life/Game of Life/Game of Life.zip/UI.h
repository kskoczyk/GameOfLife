#pragma once
#include <iostream>
#include <string>

using namespace std;

namespace UI
{
	static string message = "";
};
