#pragma once

class Cell
{
	bool isAlive;

public:
	Cell(bool &&alive);
	bool getState();
	void setState(bool &&newState);
};
