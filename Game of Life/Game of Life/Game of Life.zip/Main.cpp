// TODO:
// randomize map?
// close the streams after saving/loading

#include <iostream>
#include <vector>
#include <Windows.h>

#include <boost/thread.hpp>

#include "Cell.h"
#include "GameMap.h"
#include "UI.h"

using namespace std;

int main()
{
	gameMap::init();

	boost::thread t1([] {cin >> UI::message; });
	for ( ; ; )
	{
		gameMap::print(false);
		gameMap::iterate();

		if (t1.try_join_for(boost::chrono::milliseconds(300)))
		{
			cout << "Got " << UI::message << endl;
			//
			boost::thread t1([] {cin >> UI::message; });
			// edit config files
			Sleep(1000); // if "pause": cin >> message
		}
	}

	system("pause");
	return 0;
}