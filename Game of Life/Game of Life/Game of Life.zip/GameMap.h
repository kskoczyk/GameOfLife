#pragma once
#include <iostream>
#include <vector>
#include <algorithm>
#include <fstream>
#include <string>
#include <sstream>

#include "Cell.h"

using namespace std;

namespace gameMap
{
	void iterate();
	void init(bool &&random = false);
	void print(bool &&toFile = false);
}
